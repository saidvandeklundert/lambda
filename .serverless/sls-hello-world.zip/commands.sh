# SAM related shell script
aws mb s3://klundert-lambda-sam-bucket

# package:
aws cloudformation package --template-file template.yaml --s3-bucket klundert-lambda-sam-bucket --output-template-file cfn-out/packaged-template.yaml

# deploy:
aws cloudformation deploy --template-file cfn-out/packaged-template.yaml --stack-name klundert-lambda-sam-stack --capabilities CAPABILITY_IAM