import json
import boto3
import os
from pprint import pprint


def hello(event, context):
    client = boto3.client("lambda")
    response = client.list_functions()
    example_env_var = os.environ["ENV_VAR_EXAMPLE_1"]
    ssm = boto3.client("ssm")
    parameter = ssm.get_parameter(
        Name="/passwords/infrastructure/switch-password", WithDecryption=True
    )
    print(parameter)
    body = {
        "message": "Go Serverless v1.2! Your function executed successfully!",
        "event": event,
        "lambda-functions": response,
        "example_env_var": example_env_var,
        # "parameter": parameter,
    }

    response = {"statusCode": 200, "body": json.dumps(body)}
    # pprint(body)
    return response
